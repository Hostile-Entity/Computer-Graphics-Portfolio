Run with parameters in command line:
−out <output_path>
−scene <scene_number> //1 - ray-tracing, 2 - path-tracing
−threads <threads> - //number of threads
-samples <samples> - //number of rays in path-tracing