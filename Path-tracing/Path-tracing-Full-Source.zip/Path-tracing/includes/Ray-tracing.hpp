#ifndef RAY_TRACING_H
#define RAY_TRACING_H

#include <cstdint>
#include <cstdlib>
#include <cassert>
#include <algorithm>
#include <vector>
#include <fstream>
#include <cstring>

#include "Main.hpp"
#include "Objects.hpp"
#include "Vector3.hpp"

using namespace std;

Vec3f ray_trace( const Vec3f& rayorig, const Vec3f& raydir, const std::vector<Object*>& objects, const int& depth);

#endif 
