#ifndef OBJECTS_H
#define OBJECTS_H

#include "Vector3.hpp"

using namespace std;

class Object
{
public:
    Vec3f center;
    Vec3f surfaceColor, emissionColor;
    float reflection;

    Object(const Vec3f& c, const Vec3f& sc,
        const float& refl = 0,
        const Vec3f& ec = 0) : center(c), surfaceColor(sc), emissionColor(ec),
        reflection(refl) {};

    virtual bool intersect(const Vec3f& rayorig, const Vec3f& raydir, float& t0, float& t1) const = 0;
    virtual Vec3f normal(const Vec3f& phit) const = 0;
};

class Sphere : public Object
{
public:
    // sphere radius and radius^2 
    float radius, radius2;
    Sphere(
        const Vec3f& c,
        const float& r,
        const Vec3f& sc,
        const float& refl = 0,
        const Vec3f& ec = 0) :
        Object(c, sc, refl, ec), radius(r), radius2(r* r)
    {}

    bool intersect(const Vec3f& rayorig, const Vec3f& raydir, float& t0, float& t1) const {

        Vec3f l = Object::center - rayorig;
        float tca = l.dot(raydir);
        if (tca < 0) return false;
        float d2 = l.dot(l) - tca * tca;
        if (d2 > radius2) return false;
        float thc = sqrt(radius2 - d2);
        t0 = tca - thc;
        t1 = tca + thc;

        return true;
    }

    Vec3f normal(const Vec3f& phit) const {
        return phit - Object::center;
    }
};

class Box : public Object
{
public:
    float size, size2;
    Box(
        const Vec3f& c,
        const float& r,
        const Vec3f& sc,
        const float& refl = 0,
        const Vec3f& ec = 0) :
        Object(c, sc, refl, ec), size(r), size2(r* r)
    {}

    bool intersect(const Vec3f& ray_pos, const Vec3f& raydir, float& tmin, float& tmax) const {
        Vec3f inv_dir = Vec3f(1.0f) / raydir;

        Vec3f boxMin = Vec3f(-size) + Object::center;
        Vec3f boxMax = Vec3f(size) + Object::center;

        float lo = inv_dir.x * (boxMin.x - ray_pos.x);
        float hi = inv_dir.x * (boxMax.x - ray_pos.x);

        tmin = min(lo, hi);
        tmax = max(lo, hi);

        float lo1 = inv_dir.y * (boxMin.y - ray_pos.y);
        float hi1 = inv_dir.y * (boxMax.y - ray_pos.y);

        tmin = max(tmin, min(lo1, hi1));
        tmax = min(tmax, max(lo1, hi1));

        float lo2 = inv_dir.z * (boxMin.z - ray_pos.z);
        float hi2 = inv_dir.z * (boxMax.z - ray_pos.z);

        tmin = max(tmin, min(lo2, hi2));
        tmax = min(tmax, max(lo2, hi2));

        return (tmin <= tmax) && (tmax > 0.f);
    }

    Vec3f normal(const Vec3f& phit) const {
        Vec3f sphere_norm = phit - Object::center;
        sphere_norm.normalize();
        float angleposx = sphere_norm.dot(Vec3f(1, 0, 0));
        float anglenegx = sphere_norm.dot(Vec3f(-1, 0, 0));
        float angleposy = sphere_norm.dot(Vec3f(0, 1, 0));
        float anglenegy = sphere_norm.dot(Vec3f(0, -1, 0));
        float angleposz = sphere_norm.dot(Vec3f(0, 0, 1));
        float anglenegz = sphere_norm.dot(Vec3f(0, 0, -1));

        float minAngle = min(min(Vec3f(angleposx, angleposy, angleposz)), min(Vec3f(anglenegx, anglenegy, anglenegz)));;

        if (minAngle == angleposx) {
            return Vec3f(1, 0, 0);
        }
        if (minAngle == angleposy) {
            return Vec3f(0, 1, 0);
        }
        if (minAngle == angleposz) {
            return Vec3f(0, 0, 1);
        }
        if (minAngle == anglenegx) {
            return Vec3f(-1, 0, 0);
        }
        if (minAngle == anglenegy) {
            return Vec3f(0, -1, 0);
        }
        if (minAngle == anglenegz) {
            return Vec3f(0, 0, -1);
        }
        return Vec3f(1, 0, 0);
    }
};

class BackSphere : public Object
{
public:
    // sphere radius and radius^2 
    float radius, radius2;
    BackSphere(
        const Vec3f& c,
        const float& r,
        const Vec3f& sc,
        const float& refl = 0,
        const Vec3f& ec = 0) :
        Object(c, sc, refl, ec), radius(r), radius2(r* r)
    {}

    bool intersect(const Vec3f& rayorig, const Vec3f& raydir, float& t0, float& t1) const {
        
        Vec3f oc = rayorig - center;
        float a = raydir.dot(raydir);
        float b = 2.0 * oc.dot(raydir);
        float c = oc.dot(oc) - radius * radius;
        float discriminant = b * b - 4 * a * c;
        if (discriminant < 0) {
            return false;
        }
        t0 = (-b - sqrt(discriminant)) / (2.0 * a);
        t1 = (-b + sqrt(discriminant)) / (2.0 * a);

        return true;
    }

    Vec3f normal(const Vec3f& phit) const {
        return -(phit - Object::center);
    }
};

class Plane : public Object
{
public:
    Vec3f norm;
    Plane(
        const Vec3f& c,
        const Vec3f& r,
        const Vec3f& sc,
        const float& refl = 0,
        const Vec3f& ec = 0) :
        Object(c, sc, refl, ec), norm(r)
    {}

    bool intersect(const Vec3f& rayorig, const Vec3f& raydir, float& t0, float& t1) const {

        float denom = norm.dot(raydir);
        if (denom > EPS) {
            Vec3f p0l0 = Object::center - rayorig;
            t0 = p0l0.dot(norm) / denom;
            return true;
        }

        return false;
    }

    Vec3f normal(const Vec3f& phit) const {
        return norm;
    }
};

#endif 
