#ifndef PATH_TRACING_H
#define PATH_TRACING_H

#include <algorithm>
#include <vector>
#include <fstream>
#include <cstring>

#include "Main.hpp"
#include "Objects.hpp"
#include "Vector3.hpp"

Vec3f path_trace(Vec3f& rayorig, Vec3f& raydir, const std::vector<Object*>& objects);

#endif 
