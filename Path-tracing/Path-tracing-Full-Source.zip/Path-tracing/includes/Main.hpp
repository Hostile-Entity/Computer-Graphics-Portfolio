#ifndef MAIN_H
#define MAIN_H

#include <random>

#if defined __linux__ || defined __APPLE__ 
#include <pthread.h>
#else 
#include <windows.h>
#undef max
#undef min
#endif

#define G_PI 3.141592653589793
#define EPS 1e-4
#define INFINITY 1e8
#define MAX_RAY_DEPTH 4

using namespace std;

// random generator
static random_device rd;
static mt19937 gen(rd());
static uniform_real_distribution<float> uniform;

static float genRandomFloat() { return uniform(gen); }

#endif 
