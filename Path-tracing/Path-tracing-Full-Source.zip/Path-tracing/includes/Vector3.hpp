#ifndef VECTOR3_H
#define VECTOR3_H

#include <cmath>
#include <algorithm>
#include <fstream>
#include <iostream>

template<typename T>
class Vec3
{
public:
    T x, y, z;
    Vec3() : x(T(0)), y(T(0)), z(T(0)) {}
    Vec3(T xx) : x(xx), y(xx), z(xx) {}
    Vec3(T xx, T yy, T zz) : x(xx), y(yy), z(zz) {}
    Vec3<T> operator * (const T& f) const { return Vec3<T>(x * f, y * f, z * f); }
    Vec3<T> operator * (const Vec3<T>& v) const { return Vec3<T>(x * v.x, y * v.y, z * v.z); }
    Vec3<T> operator - (const Vec3<T>& v) const { return Vec3<T>(x - v.x, y - v.y, z - v.z); }
    Vec3<T> operator + (const Vec3<T>& v) const { return Vec3<T>(x + v.x, y + v.y, z + v.z); }
    Vec3<T> operator / (const Vec3<T>& v) const { return Vec3<T>(x / v.x, y / v.y, z / v.z); }
    Vec3<T>& operator += (const Vec3<T>& v) { x += v.x, y += v.y, z += v.z; return *this; }
    Vec3<T>& operator *= (const Vec3<T>& v) { x *= v.x, y *= v.y, z *= v.z; return *this; }
    Vec3<T> operator - () const { return Vec3<T>(-x, -y, -z); }
    inline T dot(const Vec3<T>& v) const { return x * v.x + y * v.y + z * v.z; }
    inline Vec3<T> cross(const Vec3<T>& v) const {
        return {
            y * v.z - z * v.y,
            z * v.x - x * v.z,
            x * v.y - y * v.x
        };
    }
    inline T distance(const Vec3<T>& v) const {
        Vec3<T> temp = *this - v;
        temp = temp * temp;
        return sqrt(temp.x + temp.y + temp.z);
    }
    inline T length2() const { return x * x + y * y + z * z; }
    inline T length() const { return sqrt(length2()); }
    inline T avg() const { return (x + y + z) / 3; }
    Vec3& normalize() {
        T nor2 = length2();
        if (nor2 > 0) {
            T invNor = 1 / sqrt(nor2);
            x *= invNor, y *= invNor, z *= invNor;
        }
        return *this;
    }
    friend std::ostream& operator << (std::ostream& os, const Vec3<T>& v) {
        os << "[" << v.x << " " << v.y << " " << v.z << "]";
        return os;
    }
};

template<typename T>
inline const Vec3<T> abs(const Vec3<T>& v) { return {std::abs(v.x), std::abs(v.y), std::abs(v.z)}; }

template<typename T>
inline T max(const Vec3<T>& v) { return std::max(v.x, std::max(v.y, v.z)); }

template<typename T>
inline T min(const Vec3<T>& v) { return std::min(v.x, std::min(v.y, v.z)); }

template<typename T>
inline const T clamp(const T& x, const T& low, const T& high) { if (x < low) return low; else if (x > high) return high; else return x;}

template<typename T>
inline const Vec3<T> clamp(const Vec3<T>& v, const T& low, const T& high) { return { clamp(v.x, low, high), clamp(v.y, low, high), clamp(v.z, low, high) }; }

typedef Vec3<float> Vec3f;

inline const Vec3f fclamp(const Vec3f& v, const float& low = 0.0f, const float& high = 1.0f) { return clamp(v, low, high); }

#endif 
