Run with comand line using parameters:
-scene <scene_number> (1 to 3)